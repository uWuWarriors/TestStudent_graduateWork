package com.example.teststudent

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.Postgrest
import kotlinx.coroutines.launch

class RegClass : AppCompatActivity() {
    companion object {
        private val ConnectBDClass = ConnectBD()
    }
    var mail: String? = null
    var username: String? = null
    var pass: String? = null
    var selectedRole: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
        val name_edit = findViewById(R.id.username_edit) as EditText
        val email_edit = findViewById(R.id.email_edit) as EditText
        val password_edit = findViewById(R.id.password_edit) as EditText
        val btnLog = findViewById(R.id.btn_log_1) as Button
        val btnReg = findViewById(R.id.btn_reg_1) as Button
        val radioGroup = findViewById(R.id.radioGroup) as RadioGroup
        val test = findViewById(R.id.test) as TextView

        email_edit.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0.isValidEmail()){
                    email_edit.error = null
                    btnReg.isEnabled = true
                }else{
                    email_edit.error = "Введите E-mail."
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                mail= email_edit.text.toString()
            }
        })
        name_edit.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>0){
                        name_edit.error = null
                        btnReg.isEnabled = true
                    }else{
                        name_edit.error = "Нужно ввести имя пользователя."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                username = name_edit.text.toString()
            }
        })
        password_edit.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>0){

                        password_edit.error = null
                        if (p0.trim().length>6){
                            password_edit.error = null
                        }else{
                            password_edit.error = "Пароль меньше 6 символов."
                        }
                    }else{
                        password_edit.error = "Нужно ввести пароль."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                pass = password_edit.text.toString()
            }
        })

        radioGroup.setOnCheckedChangeListener { group, checkedId ->
            selectedRole = when (checkedId) {
                R.id.radio_student -> "Student"
                R.id.radio_teacher -> "Teacher"
                else -> null
            }
        }
        btnReg.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                lifecycleScope.launch {
                    val supabase = TestSelectClass.ConnectBDClass.supabase
                    val user = supabase.auth.signUpWith(Email) {
                        email = mail.toString()
                        password = pass.toString()
                    }

                if (selectedRole == "Student") {
                    val intent = Intent(applicationContext, TestSelectClass::class.java)
                    startActivity(intent)

                } else if(selectedRole == "Teacher") {
                    val intent = Intent(applicationContext, TestSelectClass::class.java)
                    startActivity(intent)
                }
                }
        }
        })
        btnLog.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
//Переход к авторизации
            }
        })
    }
}