package com.example.teststudent

import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.postgrest.Postgrest

public class ConnectBD {
    val supabase = createSupabaseClient(
        supabaseUrl = "https://ziqygzgdllicljujwdql.supabase.co",
        supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InppcXlnemdkbGxpY2xqdWp3ZHFsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTIwNTkxNjksImV4cCI6MjAyNzYzNTE2OX0.7Y0Gz9x-TZ4VHkJ_-ywjGHfXkMG05KvpKYQ4uZLehYY"
    ) {
        install(Auth)
        install(Postgrest){
        }
    }
}