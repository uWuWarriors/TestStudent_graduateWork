package com.example.teststudent

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Columns
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable

class TestSelectClass : AppCompatActivity() {

    companion object {
        val ConnectBDClass = ConnectBD()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_testselection)
        val recyclerView = findViewById(R.id.recyclerViewTestSelection) as RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        val supabase = ConnectBDClass.supabase
        lifecycleScope.launch {
            try {
                val response = supabase.from("Test").select(columns = Columns.list("name"))

                val items = response.data?.mapNotNull { it as? Map<String, Any?> }
                    ?.map { Item(
                        it["name"] as String
                    ) } ?: emptyList()

                val ItemAdapterTestSelect = ItemAdapterTestSelect(items)
                recyclerView.adapter = ItemAdapterTestSelect
            } catch (e: Exception) {
                // Обработка ошибок
            }
        }
    }
}


@Serializable
data class Item(val name: String)