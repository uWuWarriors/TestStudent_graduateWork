package com.example.teststudent

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    var mail: String? = null
    var pass: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val edit_email = findViewById(R.id.email_edit) as EditText
        val edit_pass = findViewById(R.id.password_edit) as EditText
        val btnLog = findViewById(R.id.btn_log_1) as Button
        val btnReg = findViewById(R.id.btn_reg_1) as Button
        btnLog.isEnabled=false

        edit_email.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
                btnLog.isEnabled=false
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0.isValidEmail()){
                    edit_email.error = null
                    btnLog.isEnabled=true
                }else{
                    edit_email.error = "Введите E-mail."
                    btnLog.isEnabled=false
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                mail = edit_email.text.toString()
            }
        })
        edit_pass.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
                btnLog.isEnabled=false
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>6){
                        edit_pass.error = null
                        btnLog.isEnabled=true
                    }else{
                        edit_pass.error = "Нужно ввести пароль."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                pass = edit_pass.text.toString()
            }

        })
        btnLog.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                //Запрос авторизации с переходом на окно + запрос данных с таблицы auth.user на предмет роли
            }
        })
        btnReg.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                //переход на страницу авторизации
            }
        })

    }
}


fun CharSequence?.isValidEmail():Boolean{
    return !isNullOrEmpty() && Patterns
        .EMAIL_ADDRESS.matcher(this).matches()
}