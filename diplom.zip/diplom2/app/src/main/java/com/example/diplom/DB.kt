package com.example.diplom

import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.postgrest.Postgrest

class DB {
    val supabase = createSupabaseClient(
        supabaseUrl = "https://xihsxwwntqmeisqkudbv.supabase.co",
        supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhpaHN4d3dudHFtZWlzcWt1ZGJ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTIzNzcxMTMsImV4cCI6MjAyNzk1MzExM30.JpeTl5EGCnfeWziZxRPnpXWvjqxivyVhF1YdmHo2scs"
    ) {
        install(Auth)
        install(Postgrest){
        }
    }
}
