package com.example.diplom

import androidx.lifecycle.Lifecycle

class Item(val id: Int, val image: String, val title: String, val desc: String, val text: String) {
}

data class Item_(val id: Int, val image: Int, val title: String, val desc: String, val text: String)