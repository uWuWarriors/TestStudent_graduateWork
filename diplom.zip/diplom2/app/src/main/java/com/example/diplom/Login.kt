package com.example.diplom

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.supabaseJson
import kotlinx.coroutines.launch

class Login : AppCompatActivity() {
    companion object {
        private val ConnectBDClass = DB()
    }
    var mail: String? = null
    var pass: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)
        val edit_login = findViewById(R.id.userloginauth) as EditText
        val edit_pass = findViewById(R.id.userpassauth) as EditText
        val btnLog = findViewById(R.id.button_auth) as Button
        val btnReg = findViewById(R.id.link_to_reg) as Button
        btnLog.isEnabled=false
        val supabase = ConnectBDClass.supabase
        edit_login.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
                btnLog.isEnabled=false
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0.isValidEmail()){
                    edit_login.error = null
                    btnLog.isEnabled=true
                }else{
                    edit_login.error = "Введите E-mail."
                    btnLog.isEnabled=false
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                mail = edit_login.text.toString()
            }
        })
        edit_pass.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
                btnLog.isEnabled=false
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>6){
                        edit_pass.error = null
                        btnLog.isEnabled=true
                    }else{
                        edit_pass.error = "Нужно ввести пароль."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                pass = edit_pass.text.toString()
            }
        })
        btnLog.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                lifecycleScope.launch {
                    supabase.auth.signInWith(Email) {
                        email = mail.toString()
                        password = pass.toString()
                    }
                }
            }
        })
        btnReg.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {

            }
        })

    }
}


