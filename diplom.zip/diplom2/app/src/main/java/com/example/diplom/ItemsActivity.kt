package com.example.diplom

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ItemsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_items)


            val itemsList: RecyclerView = findViewById(R.id.commands)
        val items_ = arrayListOf<Item_>()
        items_.add(Item_(1, R.drawable.anaheim,"Anaheim Ducks","City: Anaheim, California", "Founded in 1993 year"))
        items_.add(Item_(2, R.drawable.arizona,"Arizona Coyotes","City: Arizona", "Founded in 1996 year"))
        items_.add(Item_(3, R.drawable.boston,"Boston Bruins","City: Boston, Massachusetts", "Founded in 1924 year"))
        items_.add(Item_(4, R.drawable.bufalo,"Buffalo Sabres","City: Buffalo, New York", "Founded in 1970 year"))
        items_.add(Item_(5, R.drawable.calgary,"Calgary Flames","City: Calgary, Alberta", "Founded in 1972 year "))
        items_.add(Item_(6, R.drawable.canadiens,"Montreal Canadiens","City: Montreal, Quebec", "Founded in 1909 year"))
        items_.add(Item_(7, R.drawable.carolina,"Carolina Hurricanes","City: Raleigh, North Carolina", "Founded in 1972 year"))
        items_.add(Item_(8, R.drawable.chicago,"Chicago Blackhawks","City: Chicago, Illinois", "Founded in 1926 year"))
        items_.add(Item_(9, R.drawable.colorado,"Colorado Avalanche","City: Denver, Colorado", "Founded in 1972 year"))
        items_.add(Item_(10, R.drawable.columbus,"Columbus Blue Jackets","City: Columbus, Ohio", "Founded in 2000 year"))
        items_.add(Item_(11, R.drawable.dallas,"Dallas Stars","City: Dallas, Texas", "Founded in 1967 year"))
        items_.add(Item_(12, R.drawable.detroit,"Detroit Red Wings","City: Detroit, Michigan", "Founded in 1926 year"))
        items_.add(Item_(13, R.drawable.edmonton,"Edmonton Oilers","City: Edmonton, Alberta", "Founded in 1972 year"))
        items_.add(Item_(14, R.drawable.florida,"Florida Panthers","City: Sunrise, Florida", "Founded in 1993 year"))
        items_.add(Item_(15, R.drawable.los,"Los Angeles Kings","City: Los Angeles, California", "Founded in 1967 year"))
        items_.add(Item_(16, R.drawable.minesota,"Minnesota North Stars","City: Bloomington, Minnesota", "Founded in 1967 year"))
        items_.add(Item_(17, R.drawable.nash,"Nashville Predators","City: Nashville, Tennessee", "Founded in 1998 year"))
        items_.add(Item_(18, R.drawable.newsss,"New Jersey Devils","City:Newark, New Jersey", "Founded in 1974 year"))
        items_.add(Item_(19, R.drawable.newy,"New York Islanders","City: Elmont, New York", "Founded in 1972 year"))
        items_.add(Item_(20, R.drawable.ottawa,"Ottawa Senators","City:", "Founded in 1972 year"))
        items_.add(Item_(21, R.drawable.philka,"Philadelphia Flyers","City: Philadelphia, Pennsylvania" , "Founded in 1967 year"))
        items_.add(Item_(22, R.drawable.pit,"Pittsburgh Penguins","City: Pittsburgh, Pennsylvania", "Founded in 1967 year"))
        items_.add(Item_(23, R.drawable.rangers,"New York Rangers","Home city: New York", "Founded in 1926 year"))
        items_.add(Item_(24, R.drawable.st,"St. Louis Blues","City: St. Louis, Missouri", "Founded in 1967 year"))
        items_.add(Item_(25, R.drawable.tampa,"Tampa Bay Lightning","City: Tampa, Florida", "Founded in 1992 year"))
        items_.add(Item_(26, R.drawable.toronto,"Toronto Maple Leafs","City: Toronto, Ontario", "Founded in 1917 year"))
        items_.add(Item_(27, R.drawable.vancyver,"Vancouver Canucks","City: Vancouver, British Columbia", "Founded in 1970 year"))
        items_.add(Item_(29, R.drawable.vegas,"Vegas Golden Knights","City: Paradise, Nevada", "Founded in 2017 year"))
        items_.add(Item_(30, R.drawable.washington,"Washington Capitals","City: Washington", "Founded in 1974 year"))
        items_.add(Item_(30, R.drawable.wpg,"Winnipeg Jets","Home city: Winnipeg, Manitoba", "Founded in 1999 year"))



            itemsList.layoutManager = LinearLayoutManager(this)
            itemsList.adapter = ItemsAdapter(items_, this)
        }
    }
