package com.example.diplom

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.Postgrest
import kotlinx.coroutines.launch
import org.w3c.dom.Text

class Registration : AppCompatActivity() {
    var usermail: String? = null
    var userpass: String? = null
    var userlogin: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
        val email_edit = findViewById(R.id.useremail) as EditText
        val password_edit = findViewById(R.id.userpass) as EditText
        val userlogin_edit = findViewById(R.id.userlogin) as EditText
        val btnLog = findViewById(R.id.button_reg) as Button
        val btnReg = findViewById(R.id.link_to_auth) as TextView
        val supabase = createSupabaseClient(
            supabaseUrl = "https://id.supabase.co",
            supabaseKey = "apikey"
        ) {
            install(Auth)
            install(Postgrest){
            }
        }
        btnLog.isEnabled = false
        email_edit.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0.isValidEmail()){
                    email_edit.error = null

                }else{
                    email_edit.error = "Введите E-mail."
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                usermail= email_edit.text.toString()
            }
        })
        password_edit.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>0){

                        password_edit.error = null
                        if (p0.trim().length>6){
                            password_edit.error = null
                        }else{
                            password_edit.error = "Пароль меньше 6 символов."
                        }
                    }else{
                        password_edit.error = "Нужно ввести пароль."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                userpass = password_edit.text.toString()
            }
        })

        btnReg.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                lifecycleScope.launch {
                    val user = supabase.auth.signUpWith(Email) {
                        email = usermail.toString()
                        password = userpass.toString()
                    }

                }
            }
        })
    }
}

fun CharSequence?.isValidEmail():Boolean{
    return !isNullOrEmpty() && Patterns
        .EMAIL_ADDRESS.matcher(this).matches()
}